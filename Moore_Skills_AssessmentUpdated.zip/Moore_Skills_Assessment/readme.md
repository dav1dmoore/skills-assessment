The skills assessent employs HTML, CSS, and JavaScript to render a general contacts page. The only place my solution does not match the image is the size of the column one in the selected table row. The size of the table data elements expand to the largest child within the parent table row. If I was going to do this project over I would consider employing divs, using grid to place them side by side, instead of a table markup to ensure an exact replica. Furthermore for ease of coding, I would employ jquery for easy, smooth transitioning. 

All other functionality is present.

https://dav1dmoore.github.io/skills-assessment/Moore_Skills_Assessment/skills-assessment
